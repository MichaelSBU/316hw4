export default function SplashScreen() {
    return (
        <div id="splash-screen">
            Playlister
        </div>
    )
}